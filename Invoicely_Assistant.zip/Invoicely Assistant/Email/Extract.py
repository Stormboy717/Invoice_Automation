import re

def extract_fields(eml_file):
    with open(eml_file, 'r') as f:
        content = f.read()

    subject_match = re.search(r'Subject: (.*?)\n', content, re.IGNORECASE)
    from_match = re.search(r'From: (.*?)\n', content, re.IGNORECASE)

    subject = subject_match.group(1) if subject_match else ''
    sender = from_match.group(1) if from_match else ''

    return subject, sender

# Replace 'input.eml' with the path to your .eml file
input_file = 'input.eml'

subject, sender = extract_fields(input_file)

# Save sender to a file
with open('output_sender.txt', 'w') as f:
    f.write(sender)

# Save subject to a file
with open('output_subject.txt', 'w') as f:
    f.write(subject)

print("Values extracted and saved to 'output_sender.txt' and 'output_subject.txt'.")

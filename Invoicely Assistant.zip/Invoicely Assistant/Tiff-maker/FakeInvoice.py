import os
import random
import textwrap
from datetime import datetime, timedelta
from faker import Faker
from PIL import Image, ImageDraw, ImageFont

# Generate random data
faker = Faker()

invoice_number = faker.random_number(digits=6)
order_date = datetime.now() - timedelta(days=random.randint(1, 14))
company_name = "Ultron Inc"
product_description = faker.catch_phrase()
quantity = random.randint(1, 10)
price = round(random.uniform(10.0, 100.0), 2)
bill_reference = faker.random_number(digits=8)

# Predefined values
currency = "United States Dollar - USD"
language = "English (US)"
bill_due = "Due on Receipt"

# Generate fake order notes
order_notes = faker.text(max_nb_chars=100)

# Create a blank image
width, height = 2600, 1200
image = Image.new("RGB", (width, height), "white")
draw = ImageDraw.Draw(image)

# Load fonts
font_path_regular = os.path.join("./Font/Montserrat-Regular.ttf")
font_path_bold = os.path.join("./Font/Montserrat-Bold.ttf")
font_regular = ImageFont.truetype(font_path_regular, 36)
font_bold = ImageFont.truetype(font_path_bold, 44)

# Set colors
primary_color = (44, 62, 80)
secondary_color = (236, 240, 241)
text_color = (44, 62, 80)

# Draw background rectangle
background_rect = (50, 50, width - 50, height - 50)
draw.rectangle(background_rect, fill=secondary_color)

# Draw invoice header
header_text = "INVOICE"
header_text_width, header_text_height = draw.textsize(header_text, font=font_bold)
header_text_position = ((width - header_text_width) // 2, 160)
draw.text(header_text_position, header_text, fill=primary_color, font=font_bold)

# Draw invoice elements
element_x = 150
element_y = 400
element_spacing = 70

draw.text((element_x, element_y), f"Invoice Number: {invoice_number}", fill=text_color, font=font_regular)
draw.text((element_x, element_y + element_spacing), f"Order Date: {order_date.strftime('%B %d %Y')}", fill=text_color, font=font_regular)
draw.text((element_x, element_y + 2 * element_spacing), f"Company Name: {company_name}", fill=text_color, font=font_regular)
draw.text((element_x, element_y + 3 * element_spacing), f"Product Description: {product_description}", fill=text_color, font=font_regular)
draw.text((element_x, element_y + 4 * element_spacing), f"Quantity: {quantity}", fill=text_color, font=font_regular)
draw.text((element_x, element_y + 5 * element_spacing), f"Price: {price}", fill=text_color, font=font_regular)
draw.text((element_x, element_y + 6 * element_spacing), f"Bill Reference: {bill_reference}", fill=text_color, font=font_regular)
draw.text((element_x, element_y + 7 * element_spacing), f"Currency: {currency}", fill=text_color, font=font_regular)

# Draw additional invoice details
additional_x = 1800
additional_y = element_y

draw.text((additional_x, additional_y), f"Bill due: {bill_due}", fill=text_color, font=font_regular)
draw.text((additional_x, additional_y + element_spacing), f"Language: {language}", fill=text_color, font=font_regular)

# Calculate the height required for the order notes
order_notes_box_width = 500
order_notes_box_height = height - (additional_y + 3 * element_spacing + 200)

# Draw order notes box
order_notes_box = (additional_x, additional_y + 2 * element_spacing, additional_x + order_notes_box_width, additional_y + 2 * element_spacing + order_notes_box_height)
draw.rectangle(order_notes_box, fill=secondary_color, outline=primary_color)

# Draw order notes
order_notes_text = "Order Notes:"
order_notes_text_width, order_notes_text_height = draw.textsize(order_notes_text, font=font_regular)
order_notes_text_position = (additional_x, additional_y + 2 * element_spacing)
draw.text(order_notes_text_position, order_notes_text, fill=text_color, font=font_regular)

# Wrap and draw order notes text
order_notes_font = ImageFont.truetype(font_path_regular, 28)
wrapped_order_notes = textwrap.wrap(order_notes, width=40)

line_height = order_notes_font.getsize('hg')[1]
current_height = order_notes_text_height + line_height

for line in wrapped_order_notes:
    draw.text((additional_x, additional_y + 2 * element_spacing + current_height), line, fill=text_color, font=order_notes_font)
    current_height += line_height

# Save the image as a TIFF file
output_path = "invoice.tiff"
image.save(output_path, "TIFF", compression="tiff_deflate")
print(f"Invoice created: {output_path}")
